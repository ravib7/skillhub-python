import shutil
import os

FOLDER_PATH = os.getcwd()

#create zip file 👇   👇source           👇destination
shutil.make_archive(FOLDER_PATH,"zip",FOLDER_PATH)
#                                 👆 type